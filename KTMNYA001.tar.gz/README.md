# Simple Text Based Database

## Running the application

Building and running the application is facilitated by the makefile available in the directory.

1. `make depend` Build the dependencies of the application.
2. `make main` Build the applcation executable.
3. `make run` Run the application.

## Addition supported commands

* `make clean` Clean the repository of binary files.
